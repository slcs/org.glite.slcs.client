org.glite.slcs.client
=====================

Command line interface for the Short Lived Certificate Service (SLCS). 
The user uses his Shibboleth AAI credentials to log in and receives a
short lived (valid for ~11 days) X.509 certificate.

Github Source
-------------
https://github.com/slcs/org.glite.slcs.client
